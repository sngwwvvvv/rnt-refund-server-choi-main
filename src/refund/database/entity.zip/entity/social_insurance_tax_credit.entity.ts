import { Entity, Column, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_social_insurance_tax_credit')
export class SocialInsuranceTaxCreditModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  // First Credit Years 1-5
  @Column('integer', {
    name: 'first_credit_youth_year1',
    nullable: true,
    default: 0,
  })
  firstCreditYouthYear1: number

  @Column('integer', {
    name: 'first_credit_middle_year1',
    nullable: true,
    default: 0,
  })
  firstCreditMiddleYear1: number

  @Column('integer', {
    name: 'first_credit_total_year1',
    nullable: true,
    default: 0,
  })
  firstCreditTotalYear1: number

  @Column('integer', {
    name: 'first_credit_youth_year2',
    nullable: true,
    default: 0,
  })
  firstCreditYouthYear2: number

  @Column('integer', {
    name: 'first_credit_middle_year2',
    nullable: true,
    default: 0,
  })
  firstCreditMiddleYear2: number

  @Column('integer', {
    name: 'first_credit_total_year2',
    nullable: true,
    default: 0,
  })
  firstCreditTotalYear2: number

  @Column('integer', {
    name: 'first_credit_youth_year3',
    nullable: true,
    default: 0,
  })
  firstCreditYouthYear3: number

  @Column('integer', {
    name: 'first_credit_middle_year3',
    nullable: true,
    default: 0,
  })
  firstCreditMiddleYear3: number

  @Column('integer', {
    name: 'first_credit_total_year3',
    nullable: true,
    default: 0,
  })
  firstCreditTotalYear3: number

  @Column('integer', {
    name: 'first_credit_youth_year4',
    nullable: true,
    default: 0,
  })
  firstCreditYouthYear4: number

  @Column('integer', {
    name: 'first_credit_middle_year4',
    nullable: true,
    default: 0,
  })
  firstCreditMiddleYear4: number

  @Column('integer', {
    name: 'first_credit_total_year4',
    nullable: true,
    default: 0,
  })
  firstCreditTotalYear4: number

  @Column('integer', {
    name: 'first_credit_youth_year5',
    nullable: true,
    default: 0,
  })
  firstCreditYouthYear5: number

  @Column('integer', {
    name: 'first_credit_middle_year5',
    nullable: true,
    default: 0,
  })
  firstCreditMiddleYear5: number

  @Column('integer', {
    name: 'first_credit_total_year5',
    nullable: true,
    default: 0,
  })
  firstCreditTotalYear5: number

  // Second Credit Years 1-5
  @Column('integer', {
    name: 'second_credit_youth_year1',
    nullable: true,
    default: 0,
  })
  secondCreditYouthYear1: number

  @Column('integer', {
    name: 'second_credit_middle_year1',
    nullable: true,
    default: 0,
  })
  secondCreditMiddleYear1: number

  @Column('integer', {
    name: 'second_credit_total_year1',
    nullable: true,
    default: 0,
  })
  secondCreditTotalYear1: number

  // ... Years 2-5 for second credit

  // First Paid Tax Years 1-5
  @Column('integer', {
    name: 'first_paid_tax_year1',
    nullable: true,
    default: 0,
  })
  firstPaidTaxYear1: number

  @Column('integer', {
    name: 'first_paid_tax_year2',
    nullable: true,
    default: 0,
  })
  firstPaidTaxYear2: number

  @Column('integer', {
    name: 'first_paid_tax_year3',
    nullable: true,
    default: 0,
  })
  firstPaidTaxYear3: number

  @Column('integer', {
    name: 'first_paid_tax_year4',
    nullable: true,
    default: 0,
  })
  firstPaidTaxYear4: number

  @Column('integer', {
    name: 'first_paid_tax_year5',
    nullable: true,
    default: 0,
  })
  firstPaidTaxYear5: number

  // Total Credit Years 1-5
  @Column('integer', { name: 'total_credit_year1', nullable: true, default: 0 })
  totalCreditYear1: number

  @Column('integer', { name: 'total_credit_year2', nullable: true, default: 0 })
  totalCreditYear2: number

  @Column('integer', { name: 'total_credit_year3', nullable: true, default: 0 })
  totalCreditYear3: number

  @Column('integer', { name: 'total_credit_year4', nullable: true, default: 0 })
  totalCreditYear4: number

  @Column('integer', { name: 'total_credit_year5', nullable: true, default: 0 })
  totalCreditYear5: number

  // Total Paid Tax Years 1-5
  @Column('integer', {
    name: 'total_paid_tax_year1',
    nullable: true,
    default: 0,
  })
  totalPaidTaxYear1: number

  @Column('integer', {
    name: 'total_paid_tax_year2',
    nullable: true,
    default: 0,
  })
  totalPaidTaxYear2: number

  @Column('integer', {
    name: 'total_paid_tax_year3',
    nullable: true,
    default: 0,
  })
  totalPaidTaxYear3: number

  @Column('integer', {
    name: 'total_paid_tax_year4',
    nullable: true,
    default: 0,
  })
  totalPaidTaxYear4: number

  @Column('integer', {
    name: 'total_paid_tax_year5',
    nullable: true,
    default: 0,
  })
  totalPaidTaxYear5: number

  @OneToOne(() => RefundUserModel, user => user.socialInsuranceTaxCredit, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_social_insurance_tax_credit_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel
}
