import { Entity, Column, ManyToOne, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundCompanyModel } from './refund-company.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_social_insurance_rate')
export class SocialInsuranceRateModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  @Column('uuid', {
    name: 'company_id',
    nullable: false,
  })
  companyId: string

  @Column('text', {
    name: 'workplace_manage_no',
    nullable: true,
  })
  workplaceManageNo: string

  // Year 1
  @Column('numeric', {
    name: 'normal_rate_year1',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  normalRateYear1: number

  @Column('numeric', {
    name: 'commute_accident_rate_year1',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  commuteAccidentRateYear1: number

  @Column('numeric', {
    name: 'surplus_rate_year1',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  surplusRateYear1: number

  @Column('numeric', {
    name: 'total_rate_year1',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalRateYear1: number

  // Year 2
  @Column('numeric', {
    name: 'normal_rate_year2',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  normalRateYear2: number

  @Column('numeric', {
    name: 'commute_accident_rate_year2',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  commuteAccidentRateYear2: number

  @Column('numeric', {
    name: 'surplus_rate_year2',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  surplusRateYear2: number

  @Column('numeric', {
    name: 'total_rate_year2',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalRateYear2: number

  // Year 3
  @Column('numeric', {
    name: 'normal_rate_year3',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  normalRateYear3: number

  @Column('numeric', {
    name: 'commute_accident_rate_year3',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  commuteAccidentRateYear3: number

  @Column('numeric', {
    name: 'surplus_rate_year3',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  surplusRateYear3: number

  @Column('numeric', {
    name: 'total_rate_year3',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalRateYear3: number

  // Year 4
  @Column('numeric', {
    name: 'normal_rate_year4',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  normalRateYear4: number

  @Column('numeric', {
    name: 'commute_accident_rate_year4',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  commuteAccidentRateYear4: number

  @Column('numeric', {
    name: 'surplus_rate_year4',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  surplusRateYear4: number

  @Column('numeric', {
    name: 'total_rate_year4',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalRateYear4: number

  // Year 5
  @Column('numeric', {
    name: 'normal_rate_year5',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  normalRateYear5: number

  @Column('numeric', {
    name: 'commute_accident_rate_year5',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  commuteAccidentRateYear5: number

  @Column('numeric', {
    name: 'surplus_rate_year5',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  surplusRateYear5: number

  @Column('numeric', {
    name: 'total_rate_year5',
    precision: 4,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalRateYear5: number

  @ManyToOne(() => RefundUserModel, user => user.socialInsuranceRates, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_social_insurance_rate_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel

  @OneToOne(() => RefundCompanyModel, company => company.socialInsuranceRate, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'company_id',
      referencedColumnName: 'companyId',
      foreignKeyConstraintName:
        'tb_social_insurance_rate_company_id_tb_refund_company_company_id_fk',
    },
  ])
  company: RefundCompanyModel
}
