import { Entity, Column, ManyToOne, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { WorkerType } from 'src/common/type/refund-enum.types'
import { EmployeeWorkerModel } from './employee-worker.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_integrate_monthly_count')
export class IntegrateMonthlyCountModel extends BaseModel {
  @Column('uuid', {
    name: 'employee_id',
    nullable: false,
  })
  employeeId: string

  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  @Column('text', {
    name: 'employee_name',
    nullable: true,
  })
  employeeName: string

  @Column('text', {
    name: 'employee_social_no',
    nullable: true,
  })
  employeeSocialNo: string

  @Column('text', {
    name: 'worker_type',
    nullable: true,
    default: WorkerType.OVER1YEAR,
  })
  workerType: WorkerType

  // Year 1
  @Column('integer', {
    name: 'youth_monthly_counts_year1',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear1: number

  @Column('integer', {
    name: 'middle_monthly_counts_year1',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear1: number

  @Column('integer', {
    name: 'total_monthly_counts_year1',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear1: number

  // Year 2
  @Column('integer', {
    name: 'youth_monthly_counts_year2',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear2: number

  @Column('integer', {
    name: 'middle_monthly_counts_year2',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear2: number

  @Column('integer', {
    name: 'total_monthly_counts_year2',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear2: number

  // Year 3
  @Column('integer', {
    name: 'youth_monthly_counts_year3',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear3: number

  @Column('integer', {
    name: 'middle_monthly_counts_year3',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear3: number

  @Column('integer', {
    name: 'total_monthly_counts_year3',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear3: number

  // Year 4
  @Column('integer', {
    name: 'youth_monthly_counts_year4',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear4: number

  @Column('integer', {
    name: 'middle_monthly_counts_year4',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear4: number

  @Column('integer', {
    name: 'total_monthly_counts_year4',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear4: number

  // Year 5
  @Column('integer', {
    name: 'youth_monthly_counts_year5',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear5: number

  @Column('integer', {
    name: 'middle_monthly_counts_year5',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear5: number

  @Column('integer', {
    name: 'total_monthly_counts_year5',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear5: number

  // Year 6
  @Column('integer', {
    name: 'youth_monthly_counts_year6',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear6: number

  @Column('integer', {
    name: 'middle_monthly_counts_year6',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear6: number

  @Column('integer', {
    name: 'total_monthly_counts_year6',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear6: number

  // Year 7
  @Column('integer', {
    name: 'youth_monthly_counts_year7',
    nullable: true,
    default: 0,
  })
  youthMonthlyCountsYear7: number

  @Column('integer', {
    name: 'middle_monthly_counts_year7',
    nullable: true,
    default: 0,
  })
  middleMonthlyCountsYear7: number

  @Column('integer', {
    name: 'total_monthly_counts_year7',
    nullable: true,
    default: 0,
  })
  totalMonthlyCountsYear7: number

  @ManyToOne(
    () => RefundUserModel,
    user => user.integrateMonthlyCountsRecords,
    {
      onDelete: 'CASCADE',
      onUpdate: 'RESTRICT',
    },
  )
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_integrate_monthly_count_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel

  @OneToOne(() => EmployeeWorkerModel, worker => worker.integrateMonthlyCount, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'employee_id',
      referencedColumnName: 'employeeId',
      foreignKeyConstraintName:
        'tb_integrate_monthly_count_employee_id_tb_employee_worker_employee_id_fk',
    },
  ])
  employee: EmployeeWorkerModel
}
