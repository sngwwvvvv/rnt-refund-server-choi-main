import { Entity, Column, OneToMany, OneToOne } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundCompanyModel } from './refund-company.entity'
import { IncreaseMonthlyCountModel } from './increase-monthly-counts.entity'
import { IntegrateMonthlyCountModel } from './integrate-monthly-count.entity'
import { SocialInsuranceRateModel } from './social-insurance-rate.entity'
import { IncreaseEmployeeYearlyModel } from './increase-employee-yearly.entity'
import { IntegrateEmployeeYearlyModel } from './integrate-employee-yearly.entity'
import { TotalSalaryYearlyModel } from './total-salary-yearly.entity'
import { IncreaseEmployeeTaxCreditModel } from './increase_employee_tax_credit.entity'
import { IntegrateEmployeeTaxCreditModel } from './integrate_employee_tax_credit.entity'
import { SocialInsuranceTaxCreditModel } from './social_insurance_tax_credit.entity'
import { HometaxFillingPersonModel } from './hometax_filling_person.entity'
import {
  AuthType,
  ProgressDetail,
  ProgressStatus,
  RefundStatus,
} from 'src/common/type/refund-enum.types'
import { RefundYearlyModel } from './refund_yearly.entity'
import { EmployeeWorkerModel } from './employee-worker.entity'
import { HometaxFillingCorporateModel } from './hometax_filling_corporate.entity'

@Entity('tb_refund_user')
export class RefundUserModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  @Column('text', {
    name: 'app_route',
    nullable: false,
  })
  appRoute: string

  @Column({
    type: 'text',
    name: 'cashnote_uid',
    nullable: true,
    comment: 'cashnote 고객id',
  })
  cashnoteUid: string

  @Column('text', {
    name: 'sales_code',
    nullable: true,
  })
  salesCode: string

  @Column('text', {
    name: 'user_name',
    nullable: false,
  })
  userName: string

  @Column('text', {
    name: 'user_mobile_no',
    nullable: false,
  })
  userMobileNo: string

  @Column('text', {
    name: 'user_social_no',
    nullable: false,
  })
  userSocialNo: string

  @Column('text', {
    name: 'birth-date',
    nullable: false,
  })
  birthDate: string

  @Column('boolean', {
    name: 'company_type',
    nullable: false,
  })
  companyType: boolean

  @Column('text', {
    name: 'auth_type',
    nullable: false,
    default: AuthType.SIMPLEAUTH,
  })
  authType: AuthType

  @Column('text', {
    name: 'process_status',
    nullable: false,
    default: ProgressStatus.PENDIG,
  })
  progressStatus: ProgressStatus

  @Column('text', {
    name: 'process_detail',
    nullable: false,
    default: ProgressDetail.REFUNDABLE,
  })
  progressDetail: ProgressDetail

  @Column('text', {
    name: 'refund_status',
    nullable: false,
    default: RefundStatus.APPLY,
  })
  refundStatus: RefundStatus

  @Column('text', {
    name: 'staff_name',
    nullable: true,
  })
  staffName: string

  @Column('integer', {
    name: 'estimated_refund_amt',
    nullable: false,
    default: 0,
  })
  estimatedRefundAmt: number

  @Column('integer', {
    name: 'estimated_total_carried_tax_amt',
    nullable: false,
    default: 0,
  })
  estimatedTotalCarriedTaxAmt: number

  @OneToOne(() => IncreaseEmployeeYearlyModel, yearly => yearly.user)
  increaseEmployeeYearly: IncreaseEmployeeYearlyModel

  @OneToOne(() => IntegrateEmployeeYearlyModel, yearly => yearly.user)
  integrateEmployeeYearly: IntegrateEmployeeYearlyModel

  @OneToOne(() => TotalSalaryYearlyModel, yearly => yearly.user)
  totalSalaryYearly: TotalSalaryYearlyModel

  @OneToOne(() => IncreaseEmployeeTaxCreditModel, taxCredit => taxCredit.user)
  increaseTaxCredit: IncreaseEmployeeTaxCreditModel

  @OneToOne(() => IntegrateEmployeeTaxCreditModel, taxCredit => taxCredit.user)
  integrateTaxCredit: IntegrateEmployeeTaxCreditModel

  @OneToOne(() => SocialInsuranceTaxCreditModel, taxCredit => taxCredit.user)
  socialInsuranceTaxCredit: SocialInsuranceTaxCreditModel

  @OneToOne(
    () => HometaxFillingPersonModel,
    fillingPerson => fillingPerson.user,
  )
  hometaxFillingPerson: HometaxFillingPersonModel

  @OneToOne(
    () => HometaxFillingCorporateModel,
    fillingCorporate => fillingCorporate.user,
  )
  hometaxFillingCorporate: HometaxFillingCorporateModel

  @OneToOne(() => RefundYearlyModel, refundYearly => refundYearly.user)
  refundYearly: RefundYearlyModel

  @OneToMany(() => RefundCompanyModel, company => company.refundUser)
  companies: RefundCompanyModel[]

  @OneToMany(() => EmployeeWorkerModel, worker => worker.user)
  employees: EmployeeWorkerModel[]

  @OneToMany(() => IncreaseMonthlyCountModel, monthlyCount => monthlyCount.user)
  monthlyCountsRecords: IncreaseMonthlyCountModel[]

  @OneToMany(
    () => IntegrateMonthlyCountModel,
    monthlyCount => monthlyCount.user,
  )
  integrateMonthlyCountsRecords: IntegrateMonthlyCountModel[]

  @OneToMany(() => SocialInsuranceRateModel, rate => rate.user)
  socialInsuranceRates: SocialInsuranceRateModel[]
}
