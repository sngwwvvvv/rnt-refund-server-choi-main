import { Entity, Column, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_hometax_filling_person')
export class HometaxFillingPersonModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  // Account Duty Years 1-5
  @Column('text', { name: 'account_duty_year1', nullable: true })
  accountDutyYear1: string

  @Column('text', { name: 'account_duty_year2', nullable: true })
  accountDutyYear2: string

  @Column('text', { name: 'account_duty_year3', nullable: true })
  accountDutyYear3: string

  @Column('text', { name: 'account_duty_year4', nullable: true })
  accountDutyYear4: string

  @Column('text', { name: 'account_duty_year5', nullable: true })
  accountDutyYear5: string

  // Filling Type Years 1-5
  @Column('text', { name: 'filling_type_year1', nullable: true })
  fillingTypeYear1: string

  @Column('text', { name: 'filling_type_year2', nullable: true })
  fillingTypeYear2: string

  @Column('text', { name: 'filling_type_year3', nullable: true })
  fillingTypeYear3: string

  @Column('text', { name: 'filling_type_year4', nullable: true })
  fillingTypeYear4: string

  @Column('text', { name: 'filling_type_year5', nullable: true })
  fillingTypeYear5: string

  // Agent Name Years 1-5
  @Column('text', { name: 'agent_name_year1', nullable: true })
  agentNameYear1: string

  @Column('text', { name: 'agent_name_year2', nullable: true })
  agentNameYear2: string

  @Column('text', { name: 'agent_name_year3', nullable: true })
  agentNameYear3: string

  @Column('text', { name: 'agent_name_year4', nullable: true })
  agentNameYear4: string

  @Column('text', { name: 'agent_name_year5', nullable: true })
  agentNameYear5: string

  // Income fields Years 1-5
  @Column('integer', { name: 'total_income_year1', nullable: true, default: 0 })
  totalIncomeYear1: number

  @Column('integer', { name: 'total_income_year2', nullable: true, default: 0 })
  totalIncomeYear2: number

  @Column('integer', { name: 'total_income_year3', nullable: true, default: 0 })
  totalIncomeYear3: number

  @Column('integer', { name: 'total_income_year4', nullable: true, default: 0 })
  totalIncomeYear4: number

  @Column('integer', { name: 'total_income_year5', nullable: true, default: 0 })
  totalIncomeYear5: number

  // Business Income Years 1-5
  @Column('integer', {
    name: 'business_income_year1',
    nullable: true,
    default: 0,
  })
  businessIncomeYear1: number

  @Column('integer', {
    name: 'business_income_year2',
    nullable: true,
    default: 0,
  })
  businessIncomeYear2: number

  @Column('integer', {
    name: 'business_income_year3',
    nullable: true,
    default: 0,
  })
  businessIncomeYear3: number

  @Column('integer', {
    name: 'business_income_year4',
    nullable: true,
    default: 0,
  })
  businessIncomeYear4: number

  @Column('integer', {
    name: 'business_income_year5',
    nullable: true,
    default: 0,
  })
  businessIncomeYear5: number

  // Income Deduction Years 1-5
  @Column('integer', {
    name: 'income_deduction_year1',
    nullable: true,
    default: 0,
  })
  incomeDeductionYear1: number

  @Column('integer', {
    name: 'income_deduction_year2',
    nullable: true,
    default: 0,
  })
  incomeDeductionYear2: number

  @Column('integer', {
    name: 'income_deduction_year3',
    nullable: true,
    default: 0,
  })
  incomeDeductionYear3: number

  @Column('integer', {
    name: 'income_deduction_year4',
    nullable: true,
    default: 0,
  })
  incomeDeductionYear4: number

  @Column('integer', {
    name: 'income_deduction_year5',
    nullable: true,
    default: 0,
  })
  incomeDeductionYear5: number

  // Taxation Standard Years 1-5
  @Column('integer', {
    name: 'taxation_standard_year1',
    nullable: true,
    default: 0,
  })
  taxationStandardYear1: number

  @Column('integer', {
    name: 'taxation_standard_year2',
    nullable: true,
    default: 0,
  })
  taxationStandardYear2: number

  @Column('integer', {
    name: 'taxation_standard_year3',
    nullable: true,
    default: 0,
  })
  taxationStandardYear3: number

  @Column('integer', {
    name: 'taxation_standard_year4',
    nullable: true,
    default: 0,
  })
  taxationStandardYear4: number

  @Column('integer', {
    name: 'taxation_standard_year5',
    nullable: true,
    default: 0,
  })
  taxationStandardYear5: number

  // Calculated Tax Years 1-5
  @Column('integer', {
    name: 'calculated_tax_year1',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear1: number

  @Column('integer', {
    name: 'calculated_tax_year2',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear2: number

  @Column('integer', {
    name: 'calculated_tax_year3',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear3: number

  @Column('integer', {
    name: 'calculated_tax_year4',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear4: number

  @Column('integer', {
    name: 'calculated_tax_year5',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear5: number

  // Tax Reduction Years 1-5
  @Column('integer', {
    name: 'tax_reduction_year1',
    nullable: true,
    default: 0,
  })
  taxReductionYear1: number

  @Column('integer', {
    name: 'tax_reduction_year2',
    nullable: true,
    default: 0,
  })
  taxReductionYear2: number

  @Column('integer', {
    name: 'tax_reduction_year3',
    nullable: true,
    default: 0,
  })
  taxReductionYear3: number

  @Column('integer', {
    name: 'tax_reduction_year4',
    nullable: true,
    default: 0,
  })
  taxReductionYear4: number

  @Column('integer', {
    name: 'tax_reduction_year5',
    nullable: true,
    default: 0,
  })
  taxReductionYear5: number

  // Tax Credit Years 1-5 through Business Income Rate
  @Column('numeric', {
    name: 'business_income_rate_year1',
    precision: 5,
    scale: 4,
    nullable: true,
    default: 0,
  })
  businessIncomeRateYear1: number

  @Column('numeric', {
    name: 'business_income_rate_year2',
    precision: 5,
    scale: 4,
    nullable: true,
    default: 0,
  })
  businessIncomeRateYear2: number

  @Column('numeric', {
    name: 'business_income_rate_year3',
    precision: 5,
    scale: 4,
    nullable: true,
    default: 0,
  })
  businessIncomeRateYear3: number

  @Column('numeric', {
    name: 'business_income_rate_year4',
    precision: 5,
    scale: 4,
    nullable: true,
    default: 0,
  })
  businessIncomeRateYear4: number

  @Column('numeric', {
    name: 'business_income_rate_year5',
    precision: 5,
    scale: 4,
    nullable: true,
    default: 0,
  })
  businessIncomeRateYear5: number

  // Refund Limit Years 1-5
  @Column('integer', { name: 'refund_limit_year1', nullable: true, default: 0 })
  refundLimitYear1: number

  @Column('integer', { name: 'refund_limit_year2', nullable: true, default: 0 })
  refundLimitYear2: number

  @Column('integer', { name: 'refund_limit_year3', nullable: true, default: 0 })
  refundLimitYear3: number

  @Column('integer', { name: 'refund_limit_year4', nullable: true, default: 0 })
  refundLimitYear4: number

  @Column('integer', { name: 'refund_limit_year5', nullable: true, default: 0 })
  refundLimitYear5: number

  @OneToOne(() => RefundUserModel, user => user.hometaxFillingPerson, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_hometax_filling_person_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel
}
