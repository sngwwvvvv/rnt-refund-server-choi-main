import {
  Entity,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
  OneToOne,
} from 'typeorm'
import { BaseModel } from './base.entity'
import { EmployeeWorkerModel } from './employee-worker.entity'
import { SocialInsuranceRateModel } from './social-insurance-rate.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_refund_company')
export class RefundCompanyModel extends BaseModel {
  @Column('uuid', {
    name: 'company_id',
    nullable: false,
  })
  companyId: string

  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  @Column('text', {
    name: 'company_name',
    nullable: true,
  })
  companyName: string

  @Column('text', {
    name: 'business_no',
    nullable: true,
  })
  businessNo: string

  @Column('text', {
    name: 'address',
    nullable: true,
  })
  address: string

  @Column('text', {
    name: 'workplace_manage_no',
    nullable: true,
  })
  workplaceManageNo: string

  @Column('text', {
    name: 'business_type_code',
    nullable: true,
  })
  businessTypeCode: string

  @Column('text', {
    name: 'business_start_date',
    nullable: true,
    default: '2018-01-01',
  })
  businessStartDate: string

  @Column('boolean', {
    name: 'location_type',
    nullable: true,
    default: false,
  })
  locationType: boolean

  @ManyToOne(() => RefundUserModel, user => user.companies, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_refund_company_user_id_tb_refund_user_id_fk',
    },
  ])
  refundUser: RefundUserModel

  @OneToMany(() => EmployeeWorkerModel, worker => worker.company)
  employees: EmployeeWorkerModel[]

  @OneToOne(() => SocialInsuranceRateModel, rate => rate.company)
  socialInsuranceRate: SocialInsuranceRateModel
}
