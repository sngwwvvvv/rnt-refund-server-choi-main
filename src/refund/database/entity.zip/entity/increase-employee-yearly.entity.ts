import { Entity, Column, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_increase_employee_yearly')
export class IncreaseEmployeeYearlyModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  @Column('numeric', {
    name: 'youth_counts_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear1: number

  @Column('numeric', {
    name: 'middle_counts_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear1: number

  @Column('numeric', {
    name: 'total_counts_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear1: number

  @Column('numeric', {
    name: 'youth_counts_year2',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear2: number

  @Column('numeric', {
    name: 'middle_counts_year2',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear2: number

  @Column('numeric', {
    name: 'total_counts_year2',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear2: number

  @Column('numeric', {
    name: 'youth_counts_year3',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear3: number

  @Column('numeric', {
    name: 'middle_counts_year3',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear3: number

  @Column('numeric', {
    name: 'total_counts_year3',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear3: number

  @Column('numeric', {
    name: 'youth_counts_year4',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear4: number

  @Column('numeric', {
    name: 'middle_counts_year4',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear4: number

  @Column('numeric', {
    name: 'total_counts_year4',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear4: number

  @Column('numeric', {
    name: 'youth_counts_year5',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear5: number

  @Column('numeric', {
    name: 'middle_counts_year5',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear5: number

  @Column('numeric', {
    name: 'total_counts_year5',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear5: number

  @Column('numeric', {
    name: 'youth_counts_year6',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear6: number

  @Column('numeric', {
    name: 'middle_counts_year6',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear6: number

  @Column('numeric', {
    name: 'total_counts_year6',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear6: number

  @Column('numeric', {
    name: 'youth_counts_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  youthCountsYear7: number

  @Column('numeric', {
    name: 'middle_counts_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  middleCountsYear7: number

  @Column('numeric', {
    name: 'total_counts_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  totalCountsYear7: number

  // First variation
  @Column('numeric', {
    name: 'first_variation_youth_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  firstVariationYouthYear1: number

  @Column('numeric', {
    name: 'first_variation_middle_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  firstVariationMiddleYear1: number

  @Column('numeric', {
    name: 'first_variation_total_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  firstVariationTotalYear1: number

  // Years 2-7 first variations...
  @Column('numeric', {
    name: 'first_variation_youth_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  firstVariationYouthYear7: number

  @Column('numeric', {
    name: 'first_variation_middle_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  firstVariationMiddleYear7: number

  @Column('numeric', {
    name: 'first_variation_total_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  firstVariationTotalYear7: number

  // Second variation
  @Column('numeric', {
    name: 'second_variation_youth_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  secondVariationYouthYear1: number

  @Column('numeric', {
    name: 'second_variation_middle_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  secondVariationMiddleYear1: number

  @Column('numeric', {
    name: 'second_variation_total_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  secondVariationTotalYear1: number

  // Years 2-7 second variations...
  @Column('numeric', {
    name: 'second_variation_youth_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  secondVariationYouthYear7: number

  @Column('numeric', {
    name: 'second_variation_middle_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  secondVariationMiddleYear7: number

  @Column('numeric', {
    name: 'second_variation_total_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  secondVariationTotalYear7: number

  // Third variation
  @Column('numeric', {
    name: 'third_variation_youth_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  thirdVariationYouthYear1: number

  @Column('numeric', {
    name: 'third_variation_middle_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  thirdVariationMiddleYear1: number

  @Column('numeric', {
    name: 'third_variation_total_year1',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  thirdVariationTotalYear1: number

  // Years 2-7 third variations...
  @Column('numeric', {
    name: 'third_variation_youth_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  thirdVariationYouthYear7: number

  @Column('numeric', {
    name: 'third_variation_middle_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  thirdVariationMiddleYear7: number

  @Column('numeric', {
    name: 'third_variation_total_year7',
    precision: 5,
    scale: 2,
    nullable: true,
    default: 0,
  })
  thirdVariationTotalYear7: number

  @OneToOne(() => RefundUserModel, user => user.increaseEmployeeYearly, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_increase_employee_yearly_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel
}
