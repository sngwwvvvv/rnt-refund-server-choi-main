import { Entity, Column, ManyToOne, JoinColumn, OneToOne } from 'typeorm'
import { WorkerType } from 'src/common/type/refund-enum.types'
import { BaseModel } from './base.entity'
import { IncreaseMonthlyCountModel } from './increase-monthly-counts.entity'
import { IntegrateMonthlyCountModel } from './integrate-monthly-count.entity'
import { RefundCompanyModel } from './refund-company.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_employee_worker')
export class EmployeeWorkerModel extends BaseModel {
  @Column('uuid', {
    name: 'employee_id',
    nullable: false,
  })
  employeeId: string

  @Column('uuid', {
    name: 'company_id',
    nullable: false,
  })
  companyId: string

  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  @Column('text', {
    name: 'workplace_manage_no',
    nullable: true,
  })
  workplaceManageNo: string

  @Column('text', {
    name: 'employee_name',
    nullable: true,
  })
  employeeName: string

  @Column('text', {
    name: 'employee_social_no',
    nullable: true,
  })
  employeeSocialNo: string

  @Column('text', {
    name: 'employee_start_date',
    nullable: true,
  })
  employeeStartDate: string

  @Column('text', {
    name: 'employee_end_date',
    nullable: true,
  })
  employeeEndDate: string

  @Column('integer', {
    name: 'total_salary_per_employee_year1',
    nullable: true,
    default: 0,
  })
  totalSalaryPerEmployeeYear1: number

  @Column('integer', {
    name: 'total_salary_per_employee_year2',
    nullable: true,
    default: 0,
  })
  totalSalaryPerEmployeeYear2: number

  @Column('integer', {
    name: 'total_salary_per_employee_year3',
    nullable: true,
    default: 0,
  })
  totalSalaryPerEmployeeYear3: number

  @Column('integer', {
    name: 'total_salary_per_employee_year4',
    nullable: true,
    default: 0,
  })
  totalSalaryPerEmployeeYear4: number

  @Column('integer', {
    name: 'total_salary_per_employee_year5',
    nullable: true,
    default: 0,
  })
  totalSalaryPerEmployeeYear5: number

  @Column('text', {
    name: 'worker_type',
    nullable: true,
    default: WorkerType.OVER1YEAR,
  })
  workerType: WorkerType

  @ManyToOne(() => RefundUserModel, user => user.employees, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_employee_worker_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel

  @ManyToOne(() => RefundCompanyModel, company => company.employees, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'company_id',
      referencedColumnName: 'companyId',
      foreignKeyConstraintName:
        'tb_employee_worker_company_id_tb_refund_company_company_id_fk',
    },
  ])
  company: RefundCompanyModel

  @OneToOne(
    () => IncreaseMonthlyCountModel,
    monthlyCount => monthlyCount.employee,
  )
  monthlyCount: IncreaseMonthlyCountModel

  @OneToOne(
    () => IntegrateMonthlyCountModel,
    monthlyCount => monthlyCount.employee,
  )
  integrateMonthlyCount: IntegrateMonthlyCountModel
}
