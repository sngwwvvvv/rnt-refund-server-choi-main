// refund-yearly.entity.ts - Part 1
import { Entity, Column, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_refund_yearly')
export class RefundYearlyModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  // Surplus tax fields
  @Column('integer', { name: 'surplus_tax_year1', nullable: true, default: 0 })
  surplusTaxYear1: number

  @Column('integer', { name: 'surplus_tax_year2', nullable: true, default: 0 })
  surplusTaxYear2: number

  @Column('integer', { name: 'surplus_tax_year3', nullable: true, default: 0 })
  surplusTaxYear3: number

  @Column('integer', { name: 'surplus_tax_year4', nullable: true, default: 0 })
  surplusTaxYear4: number

  @Column('integer', { name: 'surplus_tax_year5', nullable: true, default: 0 })
  surplusTaxYear5: number

  // Paid agricultural tax fields
  @Column('integer', {
    name: 'paid_agricultural_tax_year1',
    nullable: true,
    default: 0,
  })
  paidAgriculturalTaxYear1: number

  // refund-yearly.entity.ts - Part 2
  @Column('integer', {
    name: 'paid_agricultural_tax_year2',
    nullable: true,
    default: 0,
  })
  paidAgriculturalTaxYear2: number

  @Column('integer', {
    name: 'paid_agricultural_tax_year3',
    nullable: true,
    default: 0,
  })
  paidAgriculturalTaxYear3: number

  @Column('integer', {
    name: 'paid_agricultural_tax_year4',
    nullable: true,
    default: 0,
  })
  paidAgriculturalTaxYear4: number

  @Column('integer', {
    name: 'paid_agricultural_tax_year5',
    nullable: true,
    default: 0,
  })
  paidAgriculturalTaxYear5: number

  // Refund limit fields
  @Column('integer', { name: 'refund_limit_year1', nullable: true, default: 0 })
  refundLimitYear1: number

  @Column('integer', { name: 'refund_limit_year2', nullable: true, default: 0 })
  refundLimitYear2: number

  @Column('integer', { name: 'refund_limit_year3', nullable: true, default: 0 })
  refundLimitYear3: number

  @Column('integer', { name: 'refund_limit_year4', nullable: true, default: 0 })
  refundLimitYear4: number

  @Column('integer', { name: 'refund_limit_year5', nullable: true, default: 0 })
  refundLimitYear5: number

  // Increase total credit fields
  @Column('integer', {
    name: 'increase_total_credit_year1',
    nullable: true,
    default: 0,
  })
  increaseTotalCreditYear1: number

  // refund-yearly.entity.ts - Part 3
  @Column('integer', {
    name: 'increase_total_credit_year2',
    nullable: true,
    default: 0,
  })
  increaseTotalCreditYear2: number

  @Column('integer', {
    name: 'increase_total_credit_year3',
    nullable: true,
    default: 0,
  })
  increaseTotalCreditYear3: number

  @Column('integer', {
    name: 'increase_total_credit_year4',
    nullable: true,
    default: 0,
  })
  increaseTotalCreditYear4: number

  @Column('integer', {
    name: 'increase_total_credit_year5',
    nullable: true,
    default: 0,
  })
  increaseTotalCreditYear5: number

  // Integrate total credit fields
  @Column('integer', {
    name: 'integrate_total_credit_year1',
    nullable: true,
    default: 0,
  })
  integrateTotalCreditYear1: number

  @Column('integer', {
    name: 'integrate_total_credit_year2',
    nullable: true,
    default: 0,
  })
  integrateTotalCreditYear2: number

  @Column('integer', {
    name: 'integrate_total_credit_year3',
    nullable: true,
    default: 0,
  })
  integrateTotalCreditYear3: number

  @Column('integer', {
    name: 'integrate_total_credit_year4',
    nullable: true,
    default: 0,
  })
  integrateTotalCreditYear4: number

  @Column('integer', {
    name: 'integrate_total_credit_year5',
    nullable: true,
    default: 0,
  })
  integrateTotalCreditYear5: number

  // refund-yearly.entity.ts - Part 4
  // Social insurance credit fields
  @Column('integer', {
    name: 'social_insurance_total_credit_year1',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalCreditYear1: number

  @Column('integer', {
    name: 'social_insurance_total_credit_year2',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalCreditYear2: number

  @Column('integer', {
    name: 'social_insurance_total_credit_year3',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalCreditYear3: number

  @Column('integer', {
    name: 'social_insurance_total_credit_year4',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalCreditYear4: number

  @Column('integer', {
    name: 'social_insurance_total_credit_year5',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalCreditYear5: number

  // Increase total pay tax fields
  @Column('integer', {
    name: 'increase_total_pay_tax_year1',
    nullable: true,
    default: 0,
  })
  increaseTotalPayTaxYear1: number

  @Column('integer', {
    name: 'increase_total_pay_tax_year2',
    nullable: true,
    default: 0,
  })
  increaseTotalPayTaxYear2: number

  // refund-yearly.entity.ts - Part 5
  @Column('integer', {
    name: 'increase_total_pay_tax_year3',
    nullable: true,
    default: 0,
  })
  increaseTotalPayTaxYear3: number

  @Column('integer', {
    name: 'increase_total_pay_tax_year4',
    nullable: true,
    default: 0,
  })
  increaseTotalPayTaxYear4: number

  @Column('integer', {
    name: 'increase_total_pay_tax_year5',
    nullable: true,
    default: 0,
  })
  increaseTotalPayTaxYear5: number

  // Integrate total pay tax fields
  @Column('integer', {
    name: 'integrate_total_pay_tax_year1',
    nullable: true,
    default: 0,
  })
  integrateTotalPayTaxYear1: number

  @Column('integer', {
    name: 'integrate_total_pay_tax_year2',
    nullable: true,
    default: 0,
  })
  integrateTotalPayTaxYear2: number

  @Column('integer', {
    name: 'integrate_total_pay_tax_year3',
    nullable: true,
    default: 0,
  })
  integrateTotalPayTaxYear3: number

  @Column('integer', {
    name: 'integrate_total_pay_tax_year4',
    nullable: true,
    default: 0,
  })
  integrateTotalPayTaxYear4: number

  @Column('integer', {
    name: 'integrate_total_pay_tax_year5',
    nullable: true,
    default: 0,
  })
  integrateTotalPayTaxYear5: number

  // refund-yearly.entity.ts - Part 6
  // Social insurance total pay tax fields
  @Column('integer', {
    name: 'social_insurance_total_pay_tax_year1',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalPayTaxYear1: number

  @Column('integer', {
    name: 'social_insurance_total_pay_tax_year2',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalPayTaxYear2: number

  @Column('integer', {
    name: 'social_insurance_total_pay_tax_year3',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalPayTaxYear3: number

  @Column('integer', {
    name: 'social_insurance_total_pay_tax_year4',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalPayTaxYear4: number

  @Column('integer', {
    name: 'social_insurance_total_pay_tax_year5',
    nullable: true,
    default: 0,
  })
  socialInsuranceTotalPayTaxYear5: number

  // Increase yearly use credit fields
  @Column('integer', {
    name: 'increase_yearly_use_credit_year1',
    nullable: true,
    default: 0,
  })
  increaseYearlyUseCreditYear1: number

  // refund-yearly.entity.ts - Part 7
  @Column('integer', {
    name: 'increase_yearly_use_credit_year2',
    nullable: true,
    default: 0,
  })
  increaseYearlyUseCreditYear2: number

  @Column('integer', {
    name: 'increase_yearly_use_credit_year3',
    nullable: true,
    default: 0,
  })
  increaseYearlyUseCreditYear3: number

  @Column('integer', {
    name: 'increase_yearly_use_credit_year4',
    nullable: true,
    default: 0,
  })
  increaseYearlyUseCreditYear4: number

  @Column('integer', {
    name: 'increase_yearly_use_credit_year5',
    nullable: true,
    default: 0,
  })
  increaseYearlyUseCreditYear5: number

  // Integrate yearly use credit fields
  @Column('integer', {
    name: 'integrate_yearly_use_credit_year1',
    nullable: true,
    default: 0,
  })
  integrateYearlyUseCreditYear1: number

  @Column('integer', {
    name: 'integrate_yearly_use_credit_year2',
    nullable: true,
    default: 0,
  })
  integrateYearlyUseCreditYear2: number

  // refund-yearly.entity.ts - Part 8
  @Column('integer', {
    name: 'integrate_yearly_use_credit_year3',
    nullable: true,
    default: 0,
  })
  integrateYearlyUseCreditYear3: number

  @Column('integer', {
    name: 'integrate_yearly_use_credit_year4',
    nullable: true,
    default: 0,
  })
  integrateYearlyUseCreditYear4: number

  @Column('integer', {
    name: 'integrate_yearly_use_credit_year5',
    nullable: true,
    default: 0,
  })
  integrateYearlyUseCreditYear5: number

  // Social insurance yearly use credit fields
  @Column('integer', {
    name: 'social_insurance_yearly_use_credit_year1',
    nullable: true,
    default: 0,
  })
  socialInsuranceYearlyUseCreditYear1: number

  @Column('integer', {
    name: 'social_insurance_yearly_use_credit_year2',
    nullable: true,
    default: 0,
  })
  socialInsuranceYearlyUseCreditYear2: number

  @Column('integer', {
    name: 'social_insurance_yearly_use_credit_year3',
    nullable: true,
    default: 0,
  })
  socialInsuranceYearlyUseCreditYear3: number

  // refund-yearly.entity.ts - Part 9
  @Column('integer', {
    name: 'social_insurance_yearly_use_credit_year4',
    nullable: true,
    default: 0,
  })
  socialInsuranceYearlyUseCreditYear4: number

  @Column('integer', {
    name: 'social_insurance_yearly_use_credit_year5',
    nullable: true,
    default: 0,
  })
  socialInsuranceYearlyUseCreditYear5: number

  // Create agricultural tax fields
  @Column('integer', {
    name: 'create_agricultural_tax_year1',
    nullable: true,
    default: 0,
  })
  createAgriculturalTaxYear1: number

  @Column('integer', {
    name: 'create_agricultural_tax_year2',
    nullable: true,
    default: 0,
  })
  createAgriculturalTaxYear2: number

  @Column('integer', {
    name: 'create_agricultural_tax_year3',
    nullable: true,
    default: 0,
  })
  createAgriculturalTaxYear3: number

  @Column('integer', {
    name: 'create_agricultural_tax_year4',
    nullable: true,
    default: 0,
  })
  createAgriculturalTaxYear4: number

  @Column('integer', {
    name: 'create_agricultural_tax_year5',
    nullable: true,
    default: 0,
  })
  createAgriculturalTaxYear5: number

  // refund-yearly.entity.ts - Part 10
  // Increase carried tax fields
  @Column('integer', {
    name: 'increase_carried_tax_year1',
    nullable: true,
    default: 0,
  })
  increaseCarriedTaxYear1: number

  @Column('integer', {
    name: 'increase_carried_tax_year2',
    nullable: true,
    default: 0,
  })
  increaseCarriedTaxYear2: number

  @Column('integer', {
    name: 'increase_carried_tax_year3',
    nullable: true,
    default: 0,
  })
  increaseCarriedTaxYear3: number

  @Column('integer', {
    name: 'increase_carried_tax_year4',
    nullable: true,
    default: 0,
  })
  increaseCarriedTaxYear4: number

  @Column('integer', {
    name: 'increase_carried_tax_year5',
    nullable: true,
    default: 0,
  })
  increaseCarriedTaxYear5: number

  // Integrate carried tax fields
  @Column('integer', {
    name: 'integrate_carried_tax_year1',
    nullable: true,
    default: 0,
  })
  integrateCarriedTaxYear1: number

  // refund-yearly.entity.ts - Part 11
  @Column('integer', {
    name: 'integrate_carried_tax_year2',
    nullable: true,
    default: 0,
  })
  integrateCarriedTaxYear2: number

  @Column('integer', {
    name: 'integrate_carried_tax_year3',
    nullable: true,
    default: 0,
  })
  integrateCarriedTaxYear3: number

  @Column('integer', {
    name: 'integrate_carried_tax_year4',
    nullable: true,
    default: 0,
  })
  integrateCarriedTaxYear4: number

  @Column('integer', {
    name: 'integrate_carried_tax_year5',
    nullable: true,
    default: 0,
  })
  integrateCarriedTaxYear5: number

  // Social insurance carried tax fields
  @Column('integer', {
    name: 'social_insurance_carried_tax_year1',
    nullable: true,
    default: 0,
  })
  socialInsuranceCarriedTaxYear1: number

  @Column('integer', {
    name: 'social_insurance_carried_tax_year2',
    nullable: true,
    default: 0,
  })
  socialInsuranceCarriedTaxYear2: number

  // refund-yearly.entity.ts - Final Part
  @Column('integer', {
    name: 'social_insurance_carried_tax_year3',
    nullable: true,
    default: 0,
  })
  socialInsuranceCarriedTaxYear3: number

  @Column('integer', {
    name: 'social_insurance_carried_tax_year4',
    nullable: true,
    default: 0,
  })
  socialInsuranceCarriedTaxYear4: number

  @Column('integer', {
    name: 'social_insurance_carried_tax_year5',
    nullable: true,
    default: 0,
  })
  socialInsuranceCarriedTaxYear5: number

  // Total carried tax fields
  @Column('integer', {
    name: 'total_carried_tax_year1',
    nullable: true,
    default: 0,
  })
  totalCarriedTaxYear1: number

  @Column('integer', {
    name: 'total_carried_tax_year2',
    nullable: true,
    default: 0,
  })
  totalCarriedTaxYear2: number

  @Column('integer', {
    name: 'total_carried_tax_year3',
    nullable: true,
    default: 0,
  })
  totalCarriedTaxYear3: number

  @Column('integer', {
    name: 'total_carried_tax_year4',
    nullable: true,
    default: 0,
  })
  totalCarriedTaxYear4: number

  @Column('integer', {
    name: 'total_carried_tax_year5',
    nullable: true,
    default: 0,
  })
  totalCarriedTaxYear5: number

  // Refund amount fields
  @Column('integer', { name: 'refund_amt_year1', nullable: true, default: 0 })
  refundAmtYear1: number

  @Column('integer', { name: 'refund_amt_year2', nullable: true, default: 0 })
  refundAmtYear2: number

  @Column('integer', { name: 'refund_amt_year3', nullable: true, default: 0 })
  refundAmtYear3: number

  @Column('integer', { name: 'refund_amt_year4', nullable: true, default: 0 })
  refundAmtYear4: number

  @Column('integer', { name: 'refund_amt_year5', nullable: true, default: 0 })
  refundAmtYear5: number

  @OneToOne(() => RefundUserModel, user => user.refundYearly, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName: 'tb_refund_yearly_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel
}
