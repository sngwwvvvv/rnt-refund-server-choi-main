import { Entity, Column, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_hometax_filling_corporate')
export class HometaxFillingCorporateModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  // Business Period Years 1-5
  @Column('text', { name: 'business_period_year1', nullable: true })
  businessPeriodYear1: string

  @Column('text', { name: 'business_period_year2', nullable: true })
  businessPeriodYear2: string

  @Column('text', { name: 'business_period_year3', nullable: true })
  businessPeriodYear3: string

  @Column('text', { name: 'business_period_year4', nullable: true })
  businessPeriodYear4: string

  @Column('text', { name: 'business_period_year5', nullable: true })
  businessPeriodYear5: string

  // Taxation Standard Years 1-5
  @Column('integer', {
    name: 'taxation_standard_year1',
    nullable: true,
    default: 0,
  })
  taxationStandardYear1: number

  @Column('integer', {
    name: 'taxation_standard_year2',
    nullable: true,
    default: 0,
  })
  taxationStandardYear2: number

  @Column('integer', {
    name: 'taxation_standard_year3',
    nullable: true,
    default: 0,
  })
  taxationStandardYear3: number

  @Column('integer', {
    name: 'taxation_standard_year4',
    nullable: true,
    default: 0,
  })
  taxationStandardYear4: number

  @Column('integer', {
    name: 'taxation_standard_year5',
    nullable: true,
    default: 0,
  })
  taxationStandardYear5: number

  // Tax Fields Years 1-5 (all integer fields with default 0)
  @Column('integer', {
    name: 'calculated_tax_year1',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear1: number

  @Column('integer', {
    name: 'calculated_tax_year2',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear2: number

  @Column('integer', {
    name: 'calculated_tax_year3',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear3: number

  @Column('integer', {
    name: 'calculated_tax_year4',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear4: number

  @Column('integer', {
    name: 'calculated_tax_year5',
    nullable: true,
    default: 0,
  })
  calculatedTaxYear5: number

  // Tax Reduction Years 1-5
  @Column('integer', {
    name: 'tax_reduction_year1',
    nullable: true,
    default: 0,
  })
  taxReductionYear1: number

  @Column('integer', {
    name: 'tax_reduction_year2',
    nullable: true,
    default: 0,
  })
  taxReductionYear2: number

  @Column('integer', {
    name: 'tax_reduction_year3',
    nullable: true,
    default: 0,
  })
  taxReductionYear3: number

  @Column('integer', {
    name: 'tax_reduction_year4',
    nullable: true,
    default: 0,
  })
  taxReductionYear4: number

  @Column('integer', {
    name: 'tax_reduction_year5',
    nullable: true,
    default: 0,
  })
  taxReductionYear5: number

  // All other tax-related fields follow the same pattern...
  // (Adding all fields with the same pattern for years 1-5)

  // Remaining fields would continue here...

  @OneToOne(() => RefundUserModel, user => user.hometaxFillingCorporate, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_hometax_filling_corporate_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel
}
