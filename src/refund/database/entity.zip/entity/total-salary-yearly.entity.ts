import { Entity, Column, OneToOne, JoinColumn } from 'typeorm'
import { BaseModel } from './base.entity'
import { RefundUserModel } from './refund-user.entity'

@Entity('tb_total_salary_yearly')
export class TotalSalaryYearlyModel extends BaseModel {
  @Column('uuid', {
    name: 'user_id',
    nullable: false,
  })
  userId: string

  // Year 1
  @Column('integer', { name: 'youth_salary_year1', nullable: true, default: 0 })
  youthSalaryYear1: number

  @Column('integer', {
    name: 'middle_salary_year1',
    nullable: true,
    default: 0,
  })
  middleSalaryYear1: number

  @Column('integer', { name: 'total_salary_year1', nullable: true, default: 0 })
  totalSalaryYear1: number

  // Year 2
  @Column('integer', { name: 'youth_salary_year2', nullable: true, default: 0 })
  youthSalaryYear2: number

  @Column('integer', {
    name: 'middle_salary_year2',
    nullable: true,
    default: 0,
  })
  middleSalaryYear2: number

  @Column('integer', { name: 'total_salary_year2', nullable: true, default: 0 })
  totalSalaryYear2: number

  // Year 3
  @Column('integer', { name: 'youth_salary_year3', nullable: true, default: 0 })
  youthSalaryYear3: number

  @Column('integer', {
    name: 'middle_salary_year3',
    nullable: true,
    default: 0,
  })
  middleSalaryYear3: number

  @Column('integer', { name: 'total_salary_year3', nullable: true, default: 0 })
  totalSalaryYear3: number

  // Year 4
  @Column('integer', { name: 'youth_salary_year4', nullable: true, default: 0 })
  youthSalaryYear4: number

  @Column('integer', {
    name: 'middle_salary_year4',
    nullable: true,
    default: 0,
  })
  middleSalaryYear4: number

  @Column('integer', { name: 'total_salary_year4', nullable: true, default: 0 })
  totalSalaryYear4: number

  // Year 5
  @Column('integer', { name: 'youth_salary_year5', nullable: true, default: 0 })
  youthSalaryYear5: number

  @Column('integer', {
    name: 'middle_salary_year5',
    nullable: true,
    default: 0,
  })
  middleSalaryYear5: number

  @Column('integer', { name: 'total_salary_year5', nullable: true, default: 0 })
  totalSalaryYear5: number

  @OneToOne(() => RefundUserModel, user => user.totalSalaryYearly, {
    onDelete: 'CASCADE',
    onUpdate: 'RESTRICT',
  })
  @JoinColumn([
    {
      name: 'user_id',
      referencedColumnName: 'id',
      foreignKeyConstraintName:
        'tb_total_salary_yearly_user_id_tb_refund_user_id_fk',
    },
  ])
  user: RefundUserModel
}
